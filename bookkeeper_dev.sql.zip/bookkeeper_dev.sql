-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 19, 2015 at 07:16 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `bookkeeper_dev`
--

-- --------------------------------------------------------

--
-- Table structure for table `bf_activities`
--

CREATE TABLE IF NOT EXISTS `bf_activities` (
  `activity_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL DEFAULT '0',
  `activity` varchar(255) NOT NULL,
  `module` varchar(255) NOT NULL,
  `created_on` datetime NOT NULL,
  `deleted` tinyint(12) NOT NULL DEFAULT '0',
  PRIMARY KEY (`activity_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=219 ;

--
-- Dumping data for table `bf_activities`
--

INSERT INTO `bf_activities` (`activity_id`, `user_id`, `activity`, `module`, `created_on`, `deleted`) VALUES
(1, 1, 'logged in from: 127.0.0.1', 'users', '2014-01-14 05:20:32', 0),
(2, 1, 'Created Module: student : 127.0.0.1', 'modulebuilder', '2014-01-14 05:27:59', 0),
(3, 1, 'Deleted Module: student : 127.0.0.1', 'builder', '2014-01-14 05:37:45', 0),
(4, 1, 'logged in from: 127.0.0.1', 'users', '2006-12-31 18:56:09', 0),
(5, 1, 'Created record with ID: 1 : 127.0.0.1', 'student', '2006-12-31 20:19:07', 0),
(6, 1, 'logged in from: 127.0.0.1', 'users', '2014-01-25 15:04:32', 0),
(7, 1, 'logged in from: 127.0.0.1', 'users', '2014-01-26 06:04:46', 0),
(8, 1, 'Created Module: books : 127.0.0.1', 'modulebuilder', '2014-01-26 08:31:34', 0),
(9, 1, 'Created record with ID: 2 : 127.0.0.1', 'books', '2014-01-26 10:51:19', 0),
(10, 1, 'Updated record with ID: 1 : 127.0.0.1', 'books', '2014-01-26 11:12:02', 0),
(11, 1, 'logged in from: 127.0.0.1', 'users', '2014-01-26 12:48:04', 0),
(12, 1, 'logged in from: 127.0.0.1', 'users', '2014-01-26 17:47:49', 0),
(13, 1, 'logged in from: 127.0.0.1', 'users', '2014-01-28 02:31:43', 0),
(14, 1, 'Updated record with ID: 1 : 127.0.0.1', 'books', '2014-01-28 02:33:20', 0),
(15, 1, 'Updated record with ID: 2 : 127.0.0.1', 'books', '2014-01-28 02:34:07', 0),
(16, 1, 'Created Module: test : 127.0.0.1', 'modulebuilder', '2014-01-28 14:02:07', 0),
(17, 1, 'Created Module: test : 127.0.0.1', 'modulebuilder', '2014-01-28 14:31:52', 0),
(18, 1, 'Created record with ID: 1 : 127.0.0.1', 'issue_book', '2014-01-29 03:24:46', 0),
(19, 1, 'Created record with ID: 2 : 127.0.0.1', 'issue_book', '2014-01-29 03:26:14', 0),
(20, 1, 'Created record with ID: 3 : 127.0.0.1', 'issue_book', '2014-01-29 03:26:51', 0),
(21, 1, 'Updated record with ID: 1 : 127.0.0.1', 'issue_book', '2014-01-31 15:40:27', 0),
(22, 1, 'Updated record with ID: 2 : 127.0.0.1', 'issue_book', '2014-02-04 02:53:14', 0),
(23, 1, 'Updated record with ID: 2 : 127.0.0.1', 'issue_book', '2014-02-04 02:56:21', 0),
(24, 1, 'Updated record with ID: 1 : 127.0.0.1', 'student', '2014-02-04 04:12:03', 0),
(25, 1, 'Created record with ID: 2 : 127.0.0.1', 'student', '2014-02-06 02:23:58', 0),
(26, 1, 'Updated record with ID: 1 : 127.0.0.1', 'student', '2014-02-06 02:30:16', 0),
(27, 1, 'Updated record with ID: 2 : 127.0.0.1', 'student', '2014-02-06 02:30:41', 0),
(28, 1, 'Updated record with ID: 2 : 127.0.0.1', 'issue_book', '2014-02-06 02:34:36', 0),
(29, 1, 'Updated record with ID: 2 : 127.0.0.1', 'issue_book', '2014-02-06 02:38:14', 0),
(30, 1, 'Updated record with ID: 2 : 127.0.0.1', 'issue_book', '2014-02-06 02:40:38', 0),
(31, 1, 'Updated record with ID: 2 : 127.0.0.1', 'issue_book', '2014-02-06 02:44:15', 0),
(32, 1, 'Updated record with ID: 2 : 127.0.0.1', 'issue_book', '2014-02-06 02:47:11', 0),
(33, 1, 'Updated record with ID: 2 : 127.0.0.1', 'issue_book', '2014-02-06 03:01:24', 0),
(34, 1, 'Updated record with ID: 2 : 127.0.0.1', 'issue_book', '2014-02-06 03:04:34', 0),
(35, 1, 'logged out from: 127.0.0.1', 'users', '2014-02-08 02:50:46', 0),
(36, 1, 'logged in from: 127.0.0.1', 'users', '2014-02-08 03:33:01', 0),
(37, 1, 'logged in from: 127.0.0.1', 'users', '2014-02-09 06:17:20', 0),
(38, 1, 'logged in from: 127.0.0.1', 'users', '2014-02-09 08:58:12', 0),
(39, 1, 'logged in from: 127.0.0.1', 'users', '2014-02-09 09:53:19', 0),
(40, 1, 'logged in from: 127.0.0.1', 'users', '2014-02-10 02:30:01', 0),
(41, 1, 'logged in from: 127.0.0.1', 'users', '2014-02-10 03:09:59', 0),
(42, 1, 'Updated record with ID: 1 : 127.0.0.1', 'issue_book', '2014-02-10 03:58:26', 0),
(43, 1, 'Updated record with ID: 3 : 127.0.0.1', 'issue_book', '2014-02-10 03:58:33', 0),
(44, 1, 'Updated record with ID: 4 : 127.0.0.1', 'issue_book', '2014-02-10 03:58:37', 0),
(45, 1, 'logged in from: 127.0.0.1', 'users', '2014-02-11 02:24:15', 0),
(46, 1, 'Updated record with ID: 92 : 127.0.0.1', 'issue_book', '2014-02-11 03:21:39', 0),
(47, 1, 'Updated record with ID: 68 : 127.0.0.1', 'issue_book', '2014-02-11 03:22:54', 0),
(48, 1, 'Updated record with ID: 66 : 127.0.0.1', 'issue_book', '2014-02-11 03:23:41', 0),
(49, 1, 'Updated record with ID: 59 : 127.0.0.1', 'issue_book', '2014-02-11 03:24:10', 0),
(50, 1, 'Updated record with ID: 55 : 127.0.0.1', 'issue_book', '2014-02-11 03:24:37', 0),
(51, 1, 'Updated record with ID: 40 : 127.0.0.1', 'issue_book', '2014-02-11 03:25:06', 0),
(52, 1, 'Updated record with ID: 18 : 127.0.0.1', 'issue_book', '2014-02-11 03:25:32', 0),
(53, 1, 'Updated record with ID: 9 : 127.0.0.1', 'issue_book', '2014-02-11 03:25:58', 0),
(54, 1, 'Updated record with ID: 14 : 127.0.0.1', 'issue_book', '2014-02-11 03:54:24', 0),
(55, 1, 'Updated record with ID: 14 : 127.0.0.1', 'issue_book', '2014-02-11 03:55:48', 0),
(56, 1, 'Updated record with ID: 14 : 127.0.0.1', 'issue_book', '2014-02-11 04:00:03', 0),
(57, 1, 'logged in from: 127.0.0.1', 'users', '2014-02-11 14:52:52', 0),
(58, 1, ': 26 : 127.0.0.1', 'issue_book', '2014-02-11 15:18:53', 0),
(59, 1, ':  : 127.0.0.1', 'issue_book', '2014-02-11 15:33:22', 0),
(60, 1, 'logged in from: 127.0.0.1', 'users', '2014-02-11 18:08:31', 0),
(61, 1, 'logged in from: 127.0.0.1', 'users', '2014-02-11 19:40:05', 0),
(62, 1, 'logged in from: 127.0.0.1', 'users', '2014-02-12 15:15:40', 0),
(63, 1, 'logged in from: 127.0.0.1', 'users', '2014-02-14 03:37:43', 0),
(64, 1, 'logged in from: 127.0.0.1', 'users', '2014-02-14 18:21:32', 0),
(65, 1, 'Created record with ID: 11 : 127.0.0.1', 'student', '2014-02-14 19:43:23', 0),
(66, 1, 'Created record with ID: 12 : 127.0.0.1', 'student', '2014-02-14 19:45:18', 0),
(67, 1, 'Updated record with ID: 4 : 127.0.0.1', 'books', '2014-02-14 21:18:59', 0),
(68, 1, 'Created record with ID: 11 : 127.0.0.1', 'books', '2014-02-14 21:32:33', 0),
(69, 1, 'Created record with ID: 12 : 127.0.0.1', 'books', '2014-02-14 21:33:33', 0),
(70, 1, 'Created record with ID: 101 : 127.0.0.1', 'issue_book', '2014-02-14 23:41:36', 0),
(71, 1, 'Created record with ID: 102 : 127.0.0.1', 'issue_book', '2014-02-15 00:21:34', 0),
(72, 1, 'logged in from: 127.0.0.1', 'users', '2014-02-16 01:58:29', 0),
(73, 1, 'Add record with ID:  : 127.0.0.1', 'book_copies', '2014-02-16 07:44:25', 0),
(74, 1, ':  : 127.0.0.1', 'issue_book', '2014-02-16 10:08:06', 0),
(75, 1, 'Created record with ID: 103 : 127.0.0.1', 'issue_book', '2014-02-16 10:09:36', 0),
(76, 1, 'logged in from: 127.0.0.1', 'users', '2014-02-17 02:43:18', 0),
(77, 1, ':  : 127.0.0.1', 'issue_book', '2014-02-17 03:55:04', 0),
(78, 1, ':  : 127.0.0.1', 'issue_book', '2014-02-17 03:55:19', 0),
(79, 1, ':  : 127.0.0.1', 'issue_book', '2014-02-17 04:02:12', 0),
(80, 1, ':  : 127.0.0.1', 'issue_book', '2014-02-17 04:22:21', 0),
(81, 1, ':  : 127.0.0.1', 'issue_book', '2014-02-17 04:30:41', 0),
(82, 1, ':  : 127.0.0.1', 'issue_book', '2014-02-17 04:31:16', 0),
(83, 1, ':  : 127.0.0.1', 'issue_book', '2014-02-17 04:45:18', 0),
(84, 1, 'logged in from: 127.0.0.1', 'users', '2014-02-17 15:07:58', 0),
(85, 1, ':  : 127.0.0.1', 'issue_book', '2014-02-17 15:08:50', 0),
(86, 1, 'Add record with ID : 127.0.0.1', 'book_copies', '2014-02-17 18:08:29', 0),
(87, 1, 'Created record with ID: 104 : 127.0.0.1', 'issue_book', '2014-02-17 18:12:13', 0),
(88, 1, 'Created record with ID: 105 : 127.0.0.1', 'issue_book', '2014-02-17 18:14:51', 0),
(89, 1, 'logged in from: 127.0.0.1', 'users', '2014-02-18 17:03:16', 0),
(90, 1, 'logged in from: 127.0.0.1', 'users', '2014-02-18 20:27:08', 0),
(91, 1, 'Updated record with ID: 1 : 127.0.0.1', 'issue_book', '2014-02-18 20:59:33', 0),
(92, 1, 'Updated record with ID: 3 : 127.0.0.1', 'issue_book', '2014-02-18 21:03:18', 0),
(93, 1, 'Updated record with ID: 3 : 127.0.0.1', 'issue_book', '2014-02-18 21:04:24', 0),
(94, 1, 'Updated record with ID: 3 : 127.0.0.1', 'issue_book', '2014-02-18 21:05:40', 0),
(95, 1, 'Created record with ID: 106 : 127.0.0.1', 'issue_book', '2014-02-18 21:22:38', 0),
(96, 1, ':  : 127.0.0.1', 'issue_book', '2014-02-18 21:23:10', 0),
(97, 1, 'Created record with ID: 107 : 127.0.0.1', 'issue_book', '2014-02-18 21:24:29', 0),
(98, 1, ':  : 127.0.0.1', 'issue_book', '2014-02-18 21:29:47', 0),
(99, 1, 'logged in from: 127.0.0.1', 'users', '2014-02-22 02:31:35', 0),
(100, 1, ':  : 127.0.0.1', 'issue_book', '2014-02-22 03:00:40', 0),
(101, 1, 'logged in from: 127.0.0.1', 'users', '2014-02-23 08:28:45', 0),
(102, 1, 'logged out from: 127.0.0.1', 'users', '2014-02-23 08:48:23', 0),
(103, 1, 'logged in from: 127.0.0.1', 'users', '2014-02-23 09:18:06', 0),
(104, 1, 'Updated record with ID: 8 : 127.0.0.1', 'issue_book', '2014-02-23 09:46:02', 0),
(105, 1, 'logged in from: 127.0.0.1', 'users', '2014-02-24 03:33:14', 0),
(106, 1, 'Updated record with ID: 4 : 127.0.0.1', 'issue_book', '2014-02-24 03:59:59', 0),
(107, 1, 'logged out from: 127.0.0.1', 'users', '2014-02-24 04:02:52', 0),
(108, 1, 'logged in from: 127.0.0.1', 'users', '2014-02-25 01:56:12', 0),
(109, 1, 'logged in from: 127.0.0.1', 'users', '2014-02-25 13:45:07', 0),
(110, 1, 'logged in from: 127.0.0.1', 'users', '2014-02-25 18:48:50', 0),
(111, 1, 'Created record with ID: 108 : 127.0.0.1', 'issue_book', '2014-02-25 19:15:12', 0),
(112, 1, 'logged in from: 127.0.0.1', 'users', '2014-02-27 14:09:47', 0),
(113, 1, 'Created record with ID: 109 : 127.0.0.1', 'issue_book', '2014-02-27 14:28:23', 0),
(114, 1, 'Created record with ID: 108 : 127.0.0.1', 'issue_book', '2014-02-27 14:45:04', 0),
(115, 1, 'logged in from: 127.0.0.1', 'users', '2014-03-07 18:40:37', 0),
(116, 1, ':  : 127.0.0.1', 'issue_book', '2014-03-07 18:40:55', 0),
(117, 1, ':  : 127.0.0.1', 'issue_book', '2014-03-07 18:41:01', 0),
(118, 1, 'logged out from: 127.0.0.1', 'users', '2014-03-07 19:27:04', 0),
(119, 1, 'logged in from: 127.0.0.1', 'users', '2014-03-08 02:38:44', 0),
(120, 1, 'logged in from: 127.0.0.1', 'users', '2014-03-12 01:57:56', 0),
(121, 1, 'logged in from: 127.0.0.1', 'users', '2014-03-14 16:52:06', 0),
(122, 1, 'logged in from: 127.0.0.1', 'users', '2014-03-15 02:58:04', 0),
(123, 1, 'Created record with ID: 1 : 127.0.0.1', 'rack', '2014-03-15 03:28:17', 0),
(124, 1, 'Created record with ID: 4 : 127.0.0.1', 'rack', '2014-03-15 03:39:25', 0),
(125, 1, 'logged in from: 127.0.0.1', 'users', '2014-03-16 04:27:40', 0),
(126, 1, 'logged in from: 127.0.0.1', 'users', '2014-03-16 09:16:55', 0),
(127, 1, 'logged in from: 127.0.0.1', 'users', '2014-03-17 18:03:06', 0),
(128, 1, 'logged in from: 127.0.0.1', 'users', '2014-03-17 20:19:50', 0),
(129, 1, 'Add Shelves to Rack : 127.0.0.1', 'shelf', '2014-03-17 21:00:31', 0),
(130, 1, 'logged in from: 127.0.0.1', 'users', '2014-03-18 03:23:38', 0),
(131, 1, 'Add record with ID : 127.0.0.1', 'book_copies', '2014-03-18 03:45:03', 0),
(132, 1, 'Add record with ID : 127.0.0.1', 'book_copies', '2014-03-18 03:46:36', 0),
(133, 1, 'Add record with ID : 127.0.0.1', 'book_copies', '2014-03-18 03:52:05', 0),
(134, 1, 'logged in from: 127.0.0.1', 'users', '2014-03-19 01:33:50', 0),
(135, 1, 'Created record with ID: 5 : 127.0.0.1', 'rack', '2014-03-19 01:34:56', 0),
(136, 1, 'logged in from: 127.0.0.1', 'users', '2014-03-19 17:32:58', 0),
(137, 1, 'logged in from: 127.0.0.1', 'users', '2014-03-20 17:17:40', 0),
(138, 1, 'logged in from: 127.0.0.1', 'users', '2014-03-21 16:47:16', 0),
(139, 1, 'logged in from: 127.0.0.1', 'users', '2014-03-22 01:14:32', 0),
(140, 1, 'Updated record with ID: 4 : 127.0.0.1', 'issue_book', '2014-03-22 02:00:53', 0),
(141, 1, 'Created record with ID: 109 : 127.0.0.1', 'issue_book', '2014-03-22 02:02:14', 0),
(142, 1, 'Updated record with ID: 4 : 127.0.0.1', 'rack', '2014-03-22 03:49:49', 0),
(143, 1, 'logged in from: 127.0.0.1', 'users', '2014-03-22 12:11:53', 0),
(144, 1, 'logged in from: 127.0.0.1', 'users', '2014-03-23 04:44:57', 0),
(145, 1, ':  : 127.0.0.1', 'issue_book', '2014-03-23 05:20:27', 0),
(146, 1, 'logged in from: 127.0.0.1', 'users', '2014-03-26 01:53:26', 0),
(147, 1, 'logged in from: 127.0.0.1', 'users', '2014-03-27 16:40:20', 0),
(148, 1, 'Created record with ID: 6 : 127.0.0.1', 'rack', '2014-03-27 16:45:58', 0),
(149, 1, 'logged in from: 127.0.0.1', 'users', '2014-03-28 03:02:25', 0),
(150, 1, 'Created record with ID: 11 : 127.0.0.1', 'books', '2014-03-28 03:34:42', 0),
(151, 1, 'Updated record with ID: 11 : 127.0.0.1', 'books', '2014-03-28 03:42:42', 0),
(152, 1, 'Updated record with ID: 11 : 127.0.0.1', 'books', '2014-03-28 03:43:41', 0),
(153, 1, 'Updated record with ID: 11 : 127.0.0.1', 'books', '2014-03-28 03:44:45', 0),
(154, 1, 'Updated record with ID: 11 : 127.0.0.1', 'books', '2014-03-28 04:05:34', 0),
(155, 1, 'logged in from: 127.0.0.1', 'users', '2014-03-29 12:16:54', 0),
(156, 1, 'logged in from: 127.0.0.1', 'users', '2014-03-30 11:15:54', 0),
(157, 1, 'logged in from: 127.0.0.1', 'users', '2014-04-02 02:49:57', 0),
(158, 1, 'Created record with ID: 110 : 127.0.0.1', 'issue_book', '2014-04-02 02:54:13', 0),
(159, 1, 'Created record with ID: 12 : 127.0.0.1', 'student', '2014-04-02 03:18:48', 0),
(160, 1, 'Created record with ID: 111 : 127.0.0.1', 'issue_book', '2014-04-02 03:19:56', 0),
(161, 1, ':  : 127.0.0.1', 'issue_book', '2014-04-02 03:20:55', 0),
(162, 1, ':  : 127.0.0.1', 'issue_book', '2014-04-02 03:32:26', 0),
(163, 1, 'Add record with ID : 127.0.0.1', 'book_copies', '2014-04-02 03:35:57', 0),
(164, 1, 'Created record with ID: 112 : 127.0.0.1', 'issue_book', '2014-04-02 03:48:51', 0),
(165, 1, 'Updated record with ID: 112 : 127.0.0.1', 'issue_book', '2014-04-02 03:50:27', 0),
(166, 1, 'Created record with ID: 113 : 127.0.0.1', 'issue_book', '2014-04-02 03:51:15', 0),
(167, 1, 'Updated record with ID: 113 : 127.0.0.1', 'issue_book', '2014-04-02 03:51:34', 0),
(168, 1, 'Created record with ID: 114 : 127.0.0.1', 'issue_book', '2014-04-02 03:52:04', 0),
(169, 1, 'logged in from: 127.0.0.1', 'users', '2014-04-02 16:57:18', 0),
(170, 1, 'logged in from: 127.0.0.1', 'users', '2014-04-03 01:27:59', 0),
(171, 1, 'logged in from: 127.0.0.1', 'users', '2014-04-03 16:51:51', 0),
(172, 1, 'logged in from: 127.0.0.1', 'users', '2014-04-03 19:44:47', 0),
(173, 1, 'logged in from: 127.0.0.1', 'users', '2014-04-05 12:03:56', 0),
(174, 1, 'logged in from: 127.0.0.1', 'users', '2014-07-07 01:09:49', 0),
(175, 1, 'Created record with ID: 12 : 127.0.0.1', 'books', '2014-07-07 01:33:52', 0),
(176, 1, 'logged in from: 127.0.0.1', 'users', '2014-07-08 03:10:05', 0),
(177, 1, 'logged in from: 127.0.0.1', 'users', '2014-07-08 16:10:07', 0),
(178, 1, 'Created record with ID: 18 : 127.0.0.1', 'books', '2014-07-08 16:47:16', 0),
(179, 1, 'logged in from: 127.0.0.1', 'users', '2014-07-09 03:24:04', 0),
(180, 1, 'logged in from: 127.0.0.1', 'users', '2014-07-24 09:46:49', 0),
(181, 1, 'Created record with ID: 19 : 127.0.0.1', 'books', '2014-07-24 09:51:09', 0),
(182, 1, 'logged in from: 127.0.0.1', 'users', '2014-07-24 15:15:28', 0),
(183, 1, 'Add record with ID : 127.0.0.1', 'book_copies', '2014-07-24 15:16:21', 0),
(184, 1, 'logged in from: 127.0.0.1', 'users', '2014-07-24 15:45:42', 0),
(185, 1, 'logged in from: 127.0.0.1', 'users', '2014-07-25 17:13:16', 0),
(186, 1, 'logged in from: 127.0.0.1', 'users', '2014-08-06 02:09:53', 0),
(187, 1, 'Add record with ID : 127.0.0.1', 'book_copies', '2014-08-06 02:34:00', 0),
(188, 1, 'Add record with ID : 127.0.0.1', 'book_copies', '2014-08-06 02:35:06', 0),
(189, 1, 'Add record with ID : 127.0.0.1', 'book_copies', '2014-08-06 03:17:31', 0),
(190, 1, 'logged in from: 127.0.0.1', 'users', '2014-08-06 13:54:08', 0),
(191, 1, 'logged in from: 127.0.0.1', 'users', '2015-01-17 09:10:59', 0),
(192, 1, 'logged out from: 127.0.0.1', 'users', '2015-01-17 09:56:18', 0),
(193, 1, 'logged in from: 127.0.0.1', 'users', '2015-01-17 12:19:03', 0),
(194, 1, 'Add record with ID : 127.0.0.1', 'book_copies', '2015-01-17 13:16:37', 0),
(195, 1, 'logged in from: 127.0.0.1', 'users', '2015-01-19 06:23:01', 0),
(196, 1, 'logged out from: 127.0.0.1', 'users', '2015-01-19 06:25:39', 0),
(197, 1, 'logged in from: 127.0.0.1', 'users', '2015-01-19 06:30:54', 0),
(198, 1, 'logged out from: 127.0.0.1', 'users', '2015-01-19 06:31:59', 0),
(199, 1, 'logged in from: 127.0.0.1', 'users', '2015-01-19 06:33:26', 0),
(200, 1, 'Updated record with ID: 3 : 127.0.0.1', 'issue_book', '2015-01-19 06:45:43', 0),
(201, 1, 'Updated record with ID: 11 : 127.0.0.1', 'issue_book', '2015-01-19 06:45:48', 0),
(202, 1, 'Updated record with ID: 105 : 127.0.0.1', 'issue_book', '2015-01-19 06:45:52', 0),
(203, 1, 'Updated record with ID: 107 : 127.0.0.1', 'issue_book', '2015-01-19 06:45:54', 0),
(204, 1, 'Updated record with ID: 107 : 127.0.0.1', 'issue_book', '2015-01-19 06:45:56', 0),
(205, 1, 'Updated record with ID: 108 : 127.0.0.1', 'issue_book', '2015-01-19 06:45:59', 0),
(206, 1, 'Updated record with ID: 108 : 127.0.0.1', 'issue_book', '2015-01-19 06:46:00', 0),
(207, 1, 'Updated record with ID: 108 : 127.0.0.1', 'issue_book', '2015-01-19 06:46:01', 0),
(208, 1, 'Updated record with ID: 108 : 127.0.0.1', 'issue_book', '2015-01-19 06:46:02', 0),
(209, 1, 'Updated record with ID: 108 : 127.0.0.1', 'issue_book', '2015-01-19 06:46:02', 0),
(210, 1, 'Updated record with ID: 108 : 127.0.0.1', 'issue_book', '2015-01-19 06:46:04', 0),
(211, 1, 'Updated record with ID: 108 : 127.0.0.1', 'issue_book', '2015-01-19 06:46:04', 0),
(212, 1, 'Updated record with ID: 108 : 127.0.0.1', 'issue_book', '2015-01-19 06:46:05', 0),
(213, 1, 'Updated record with ID: 108 : 127.0.0.1', 'issue_book', '2015-01-19 06:46:06', 0),
(214, 1, 'Updated record with ID: 108 : 127.0.0.1', 'issue_book', '2015-01-19 06:46:06', 0),
(215, 1, 'Updated record with ID: 108 : 127.0.0.1', 'issue_book', '2015-01-19 06:46:07', 0),
(216, 1, 'Updated record with ID: 108 : 127.0.0.1', 'issue_book', '2015-01-19 06:46:08', 0),
(217, 1, 'Updated record with ID: 108 : 127.0.0.1', 'issue_book', '2015-01-19 06:46:08', 0),
(218, 1, 'Updated record with ID: 114 : 127.0.0.1', 'issue_book', '2015-01-19 06:46:11', 0);

-- --------------------------------------------------------

--
-- Table structure for table `bf_books`
--

CREATE TABLE IF NOT EXISTS `bf_books` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `isbn` varchar(20) DEFAULT NULL,
  `title` varchar(150) DEFAULT NULL,
  `author` varchar(150) DEFAULT NULL,
  `publisher` varchar(150) DEFAULT NULL,
  `year` year(4) DEFAULT NULL,
  `class_name` varchar(50) DEFAULT NULL,
  `category_name` varchar(50) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_on` datetime DEFAULT NULL,
  `modified_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=25 ;

--
-- Dumping data for table `bf_books`
--

INSERT INTO `bf_books` (`id`, `isbn`, `title`, `author`, `publisher`, `year`, `class_name`, `category_name`, `deleted`, `created_on`, `modified_on`) VALUES
(1, '87235', 'Holmes Gillespie', 'Jermaine Foster', 'Rosa, Akeem X.', 1999, NULL, NULL, 1, '2013-02-21 16:21:41', '2013-06-13 09:41:00'),
(2, '54141', 'Drake Kirk', 'Armando Cooley', 'Garcia, Hanna X.', 2012, NULL, NULL, 1, '2013-07-25 16:01:33', '2013-11-18 21:57:41'),
(3, '02914', 'Emmanuel Lindsey', 'Yardley Soto', 'Sargent, Nolan E.', 2005, NULL, NULL, 1, '2013-12-08 21:33:35', '2013-12-09 13:43:48'),
(4, '15521', 'Chase Fernandezo', 'Murphy Delgado', 'Thompson, Brittany A.', 2012, NULL, NULL, 1, '2013-11-28 12:44:55', '2014-02-14 21:18:59'),
(5, '54830', 'Tate Kennedy', 'Calvin Larsen', 'Haynes, Castor M.', 2007, NULL, NULL, 1, '2013-03-25 21:36:16', '2013-12-25 05:20:39'),
(6, '80876', 'Jacob Mckee', 'Walker Reynolds', 'Greene, Burton P.', 2003, NULL, NULL, 1, '2013-12-23 13:39:21', '2013-12-30 20:42:12'),
(7, '80379', 'Tucker Hutchinson', 'Dean Herring', 'Deleon, Robert M.', 1998, NULL, NULL, 1, '2013-07-20 02:30:37', '2013-10-08 13:32:00'),
(8, '46321', 'Ian Kemp', 'Chadwick Gaines', 'Hudson, Ciara V.', 2001, NULL, NULL, 1, '2013-11-20 16:23:07', '2013-03-10 04:07:07'),
(9, '89030', 'Ulysses Whitehead', 'Chaim Kaufman', 'Moody, Dalton L.', 2013, NULL, NULL, 1, '2013-11-22 05:31:07', '2013-04-06 16:33:30'),
(10, '72325', 'Brock Mcconnell', 'Craig Peters', 'Benjamin, Hoyt A.', 2002, NULL, NULL, 1, '2013-09-10 21:56:54', '2013-07-27 03:47:09'),
(11, '123', 'test test xyz', 'auth auth test', 'pub pub test', 1992, 'test class', 'test cate', 1, '2014-03-28 03:34:42', '2014-03-28 04:05:34'),
(12, '90123', 'test90', 'test90', 'test90', 1975, 'test90', 'test90', 1, '2014-07-07 01:33:52', NULL),
(16, '90123', 'testing321456', 'testing321456', 'testing321456', 1975, 'test class', 'test cate', 1, '2014-07-08 16:45:47', NULL),
(18, '90123', 'testing321456', 'testing321456', 'testing321456', 1975, 'test class', 'test cate', 1, '2014-07-08 16:47:16', NULL),
(19, '123', 'asrar hussain', 'asrar hussain', 'asrar hussain', 1985, 'test class', 'test90', 1, '2014-07-24 09:51:09', NULL),
(23, '123', 'qwerty', 'aasdasd', 'asdasd', 1975, 'test class', 'test cate', 1, '2014-08-06 02:37:21', NULL),
(24, '', 'abc12345', '', '', 1975, '', '', 1, '2014-08-06 03:16:55', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `bf_book_copies`
--

CREATE TABLE IF NOT EXISTS `bf_book_copies` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `book_uid` int(10) DEFAULT NULL,
  `book_id` int(10) NOT NULL,
  `issued` int(10) NOT NULL DEFAULT '0',
  `deleted` int(10) DEFAULT '0',
  `created_on` datetime DEFAULT '0000-00-00 00:00:00',
  `modified_on` datetime DEFAULT '0000-00-00 00:00:00',
  `donated` tinyint(1) DEFAULT '0',
  `purchase_by` varchar(50) DEFAULT NULL,
  `purchase_date` datetime DEFAULT '0000-00-00 00:00:00',
  `price` double DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `book_uid` (`book_uid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=43 ;

--
-- Dumping data for table `bf_book_copies`
--

INSERT INTO `bf_book_copies` (`id`, `book_uid`, `book_id`, `issued`, `deleted`, `created_on`, `modified_on`, `donated`, `purchase_by`, `purchase_date`, `price`) VALUES
(1, NULL, 1, 0, 1, '2002-02-12 00:00:00', '2014-02-18 20:54:31', 0, '0', '0000-00-00 00:00:00', NULL),
(2, NULL, 1, 0, 1, '2002-02-12 00:00:00', '2014-02-17 15:08:50', 0, '0', '0000-00-00 00:00:00', NULL),
(3, NULL, 2, 1, 1, '2002-02-12 00:00:00', '0000-00-00 00:00:00', 0, '0', '0000-00-00 00:00:00', NULL),
(4, NULL, 2, 1, 1, '2002-02-12 00:00:00', '2014-02-17 18:14:51', 0, '0', '0000-00-00 00:00:00', NULL),
(5, NULL, 2, 0, 1, '2002-02-12 00:00:00', '0000-00-00 00:00:00', 0, '0', '0000-00-00 00:00:00', NULL),
(6, NULL, 3, 0, 1, '2002-02-12 00:00:00', '2014-02-17 04:45:18', 0, '0', '0000-00-00 00:00:00', NULL),
(7, NULL, 3, 0, 1, '2002-02-12 00:00:00', '2014-02-17 04:31:16', 0, '0', '0000-00-00 00:00:00', NULL),
(8, NULL, 4, 1, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, '0', '0000-00-00 00:00:00', NULL),
(9, NULL, 4, 1, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, '0', '0000-00-00 00:00:00', NULL),
(10, NULL, 4, 1, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, '0', '0000-00-00 00:00:00', NULL),
(11, NULL, 6, 1, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, '0', '0000-00-00 00:00:00', NULL),
(13, NULL, 1, 1, 1, '0000-00-00 00:00:00', '2014-02-18 21:24:29', 0, '0', '0000-00-00 00:00:00', NULL),
(14, NULL, 1, 0, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, '0', '0000-00-00 00:00:00', NULL),
(15, NULL, 5, 0, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, '0', '0000-00-00 00:00:00', NULL),
(16, NULL, 5, 0, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, '0', '0000-00-00 00:00:00', NULL),
(17, NULL, 5, 0, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, '0', '0000-00-00 00:00:00', NULL),
(18, NULL, 5, 0, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, '0', '0000-00-00 00:00:00', NULL),
(19, NULL, 6, 0, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, '0', '0000-00-00 00:00:00', NULL),
(20, 20, 3, 0, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'abc', '2014-03-30 00:00:00', NULL),
(21, 21, 3, 0, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'abc', '2014-03-31 00:00:00', NULL),
(30, 30, 18, 0, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'xyz', '2014-07-02 00:00:00', 123),
(31, 31, 18, 0, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'abc', '2014-07-03 00:00:00', 456),
(32, 32, 19, 0, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'abc', '2014-07-01 00:00:00', 1200),
(33, 33, 19, 0, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'xyz', '2014-07-09 00:00:00', 1500),
(34, 34, 19, 0, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mnb', '2014-07-16 00:00:00', 123),
(37, 35, 12, 0, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'aaa', '2014-08-03 00:00:00', 123),
(38, 36, 12, 0, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'bbb', '2014-08-02 00:00:00', 321),
(39, 39, 12, 0, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'aaa', '2014-08-29 00:00:00', 123),
(40, 40, 12, 0, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'bbb', '2014-08-01 00:00:00', 321),
(41, 41, 24, 0, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mnb', '2014-08-26 00:00:00', 120),
(42, 42, 9, 0, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'asrar', '2015-01-12 00:00:00', 100);

-- --------------------------------------------------------

--
-- Table structure for table `bf_category`
--

CREATE TABLE IF NOT EXISTS `bf_category` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `bf_category`
--


-- --------------------------------------------------------

--
-- Table structure for table `bf_class`
--

CREATE TABLE IF NOT EXISTS `bf_class` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `bf_class`
--


-- --------------------------------------------------------

--
-- Table structure for table `bf_email_queue`
--

CREATE TABLE IF NOT EXISTS `bf_email_queue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `to_email` varchar(128) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `alt_message` text,
  `max_attempts` int(11) NOT NULL DEFAULT '3',
  `attempts` int(11) NOT NULL DEFAULT '0',
  `success` tinyint(1) NOT NULL DEFAULT '0',
  `date_published` datetime DEFAULT NULL,
  `last_attempt` datetime DEFAULT NULL,
  `date_sent` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `bf_email_queue`
--


-- --------------------------------------------------------

--
-- Table structure for table `bf_issue_book`
--

CREATE TABLE IF NOT EXISTS `bf_issue_book` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `book_id` int(10) NOT NULL DEFAULT '0',
  `book_copy_id` int(10) NOT NULL DEFAULT '0',
  `student_id` int(10) NOT NULL DEFAULT '0',
  `issue_date` datetime NOT NULL,
  `return_date` datetime NOT NULL,
  `submit_date` datetime DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=115 ;

--
-- Dumping data for table `bf_issue_book`
--

INSERT INTO `bf_issue_book` (`id`, `book_id`, `book_copy_id`, `student_id`, `issue_date`, `return_date`, `submit_date`, `active`, `deleted`, `created_on`, `modified_on`) VALUES
(1, 1, 1, 4, '2014-02-03 14:03:34', '2014-02-15 18:32:05', '2014-02-18 00:00:00', 0, 0, '2014-07-18 11:05:16', '2014-02-18 20:59:33'),
(2, 1, 2, 3, '2014-02-05 15:55:20', '2014-02-08 22:11:50', '2014-02-17 00:00:00', 0, 0, '2014-04-30 09:45:26', '2014-02-17 15:08:50'),
(3, 2, 2, 10, '2014-02-04 00:00:00', '2014-02-08 00:00:00', '2015-01-19 00:00:00', 0, 0, '2014-02-26 05:27:21', '2015-01-19 06:45:43'),
(4, 3, 6, 8, '2014-02-03 00:00:00', '2014-02-06 00:00:00', '2014-03-22 00:00:00', 0, 0, '2014-08-27 03:08:35', '2014-03-22 02:00:53'),
(5, 3, 6, 7, '2014-02-02 01:23:19', '2014-02-05 12:08:43', '2014-02-17 00:00:00', 0, 0, '2014-06-17 13:19:35', '2014-02-17 04:45:18'),
(6, 2, 5, 9, '2014-02-04 11:22:49', '2014-02-11 03:25:57', '2014-02-17 00:00:00', 0, 0, '2014-03-27 01:02:43', '2014-02-17 04:05:03'),
(7, 4, 10, 2, '2014-02-02 11:47:05', '2014-02-11 15:18:09', '2014-02-22 00:00:00', 0, 0, '2014-05-02 13:14:26', '2014-02-22 03:00:40'),
(8, 4, 8, 4, '2014-02-05 00:00:00', '2014-02-28 00:00:00', '2014-03-07 00:00:00', 0, 0, '2014-08-28 18:54:36', '2014-03-07 18:40:55'),
(9, 3, 7, 10, '2014-02-02 02:18:40', '2014-02-11 16:57:51', '2014-02-17 00:00:00', 0, 0, '2014-04-17 13:06:06', '2014-02-17 04:31:16'),
(10, 4, 9, 2, '2014-02-04 09:31:56', '2014-02-06 04:34:21', '2014-03-07 00:00:00', 0, 0, '2014-02-01 10:37:12', '2014-03-07 18:41:01'),
(11, 6, 11, 6, '2014-02-05 09:36:11', '2014-02-09 08:00:45', '2015-01-19 00:00:00', 0, 0, '2014-12-27 10:40:17', '2015-01-19 06:45:48'),
(104, 2, 4, 3, '2014-02-17 00:00:00', '2012-02-25 00:00:00', '2014-02-18 00:00:00', 0, 0, '2014-02-17 18:12:13', '2014-02-18 21:29:46'),
(105, 2, 4, 6, '2014-02-17 00:00:00', '2012-02-25 00:00:00', '2015-01-19 00:00:00', 0, 0, '2014-02-17 18:14:51', '2015-01-19 06:45:51'),
(106, 1, 13, 3, '2014-02-19 00:00:00', '2014-02-26 00:00:00', '2014-02-18 00:00:00', 0, 0, '2014-02-18 21:22:38', '2014-02-18 21:23:09'),
(107, 1, 13, 3, '2014-02-19 00:00:00', '2014-02-26 00:00:00', '2015-01-19 00:00:00', 0, 0, '2014-02-18 21:24:29', '2015-01-19 06:45:56'),
(108, 3, 6, 11, '2014-02-27 00:00:00', '2014-03-08 00:00:00', '2015-01-19 00:00:00', 0, 0, '2014-02-27 14:45:04', '2015-01-19 06:46:08'),
(109, 3, 7, 2, '2014-03-22 00:00:00', '2014-03-31 00:00:00', '2014-03-23 00:00:00', 0, 0, '2014-03-22 02:02:14', '2014-03-23 05:20:27'),
(110, 3, 7, 6, '2014-04-02 00:00:00', '2014-04-19 00:00:00', '2014-04-02 00:00:00', 0, 0, '2014-04-02 02:54:13', '2014-04-02 03:32:26'),
(111, 5, 15, 12, '2014-04-02 00:00:00', '2014-04-05 00:00:00', '2014-04-02 00:00:00', 0, 0, '2014-04-02 03:19:56', '2014-04-02 03:20:55'),
(112, 6, 19, 3, '2014-04-02 00:00:00', '2014-04-18 00:00:00', '2014-04-02 00:00:00', 0, 0, '2014-04-02 03:48:51', '2014-04-02 03:50:27'),
(113, 6, 19, 2, '2014-04-02 00:00:00', '2014-04-23 00:00:00', '2014-04-02 00:00:00', 0, 0, '2014-04-02 03:51:15', '2014-04-02 03:51:34'),
(114, 6, 19, 6, '2014-04-02 00:00:00', '2014-04-16 00:00:00', '2015-01-19 00:00:00', 0, 0, '2014-04-02 03:52:04', '2015-01-19 06:46:10');

-- --------------------------------------------------------

--
-- Table structure for table `bf_login_attempts`
--

CREATE TABLE IF NOT EXISTS `bf_login_attempts` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(40) NOT NULL,
  `login` varchar(50) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `bf_login_attempts`
--


-- --------------------------------------------------------

--
-- Table structure for table `bf_permissions`
--

CREATE TABLE IF NOT EXISTS `bf_permissions` (
  `permission_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `description` varchar(100) NOT NULL,
  `status` enum('active','inactive','deleted') DEFAULT 'active',
  PRIMARY KEY (`permission_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=83 ;

--
-- Dumping data for table `bf_permissions`
--

INSERT INTO `bf_permissions` (`permission_id`, `name`, `description`, `status`) VALUES
(1, 'Site.Signin.Allow', 'Allow users to login to the site', 'active'),
(2, 'Site.Content.View', 'Allow users to view the Content Context', 'active'),
(3, 'Site.Reports.View', 'Allow users to view the Reports Context', 'active'),
(4, 'Site.Settings.View', 'Allow users to view the Settings Context', 'active'),
(5, 'Site.Developer.View', 'Allow users to view the Developer Context', 'active'),
(6, 'Bonfire.Roles.Manage', 'Allow users to manage the user Roles', 'active'),
(7, 'Bonfire.Users.Manage', 'Allow users to manage the site Users', 'active'),
(8, 'Bonfire.Users.View', 'Allow users access to the User Settings', 'active'),
(9, 'Bonfire.Users.Add', 'Allow users to add new Users', 'active'),
(10, 'Bonfire.Database.Manage', 'Allow users to manage the Database settings', 'active'),
(11, 'Bonfire.Emailer.Manage', 'Allow users to manage the Emailer settings', 'active'),
(12, 'Bonfire.Logs.View', 'Allow users access to the Log details', 'active'),
(13, 'Bonfire.Logs.Manage', 'Allow users to manage the Log files', 'active'),
(14, 'Bonfire.Emailer.View', 'Allow users access to the Emailer settings', 'active'),
(15, 'Site.Signin.Offline', 'Allow users to login to the site when the site is offline', 'active'),
(16, 'Bonfire.Permissions.View', 'Allow access to view the Permissions menu unders Settings Context', 'active'),
(17, 'Bonfire.Permissions.Manage', 'Allow access to manage the Permissions in the system', 'active'),
(18, 'Bonfire.Roles.Delete', 'Allow users to delete user Roles', 'active'),
(19, 'Bonfire.Modules.Add', 'Allow creation of modules with the builder.', 'active'),
(20, 'Bonfire.Modules.Delete', 'Allow deletion of modules.', 'active'),
(21, 'Permissions.Administrator.Manage', 'To manage the access control permissions for the Administrator role.', 'active'),
(22, 'Permissions.Editor.Manage', 'To manage the access control permissions for the Editor role.', 'active'),
(24, 'Permissions.User.Manage', 'To manage the access control permissions for the User role.', 'active'),
(25, 'Permissions.Developer.Manage', 'To manage the access control permissions for the Developer role.', 'active'),
(27, 'Activities.Own.View', 'To view the users own activity logs', 'active'),
(28, 'Activities.Own.Delete', 'To delete the users own activity logs', 'active'),
(29, 'Activities.User.View', 'To view the user activity logs', 'active'),
(30, 'Activities.User.Delete', 'To delete the user activity logs, except own', 'active'),
(31, 'Activities.Module.View', 'To view the module activity logs', 'active'),
(32, 'Activities.Module.Delete', 'To delete the module activity logs', 'active'),
(33, 'Activities.Date.View', 'To view the users own activity logs', 'active'),
(34, 'Activities.Date.Delete', 'To delete the dated activity logs', 'active'),
(35, 'Bonfire.UI.Manage', 'Manage the Bonfire UI settings', 'active'),
(36, 'Bonfire.Settings.View', 'To view the site settings page.', 'active'),
(37, 'Bonfire.Settings.Manage', 'To manage the site settings.', 'active'),
(38, 'Bonfire.Activities.View', 'To view the Activities menu.', 'active'),
(39, 'Bonfire.Database.View', 'To view the Database menu.', 'active'),
(40, 'Bonfire.Migrations.View', 'To view the Migrations menu.', 'active'),
(41, 'Bonfire.Builder.View', 'To view the Modulebuilder menu.', 'active'),
(42, 'Bonfire.Roles.View', 'To view the Roles menu.', 'active'),
(43, 'Bonfire.Sysinfo.View', 'To view the System Information page.', 'active'),
(44, 'Bonfire.Translate.Manage', 'To manage the Language Translation.', 'active'),
(45, 'Bonfire.Translate.View', 'To view the Language Translate menu.', 'active'),
(46, 'Bonfire.UI.View', 'To view the UI/Keyboard Shortcut menu.', 'active'),
(47, 'Bonfire.Update.Manage', 'To manage the Bonfire Update.', 'active'),
(48, 'Bonfire.Update.View', 'To view the Developer Update menu.', 'active'),
(49, 'Bonfire.Profiler.View', 'To view the Console Profiler Bar.', 'active'),
(50, 'Bonfire.Roles.Add', 'To add New Roles', 'active'),
(51, 'Books.Content.View', '', 'active'),
(52, 'Books.Content.Create', '', 'active'),
(53, 'Books.Content.Edit', '', 'active'),
(54, 'Books.Content.Delete', '', 'active'),
(55, 'Books.Reports.View', '', 'active'),
(56, 'Books.Reports.Create', '', 'active'),
(57, 'Books.Reports.Edit', '', 'active'),
(58, 'Books.Reports.Delete', '', 'active'),
(59, 'Books.Settings.View', '', 'active'),
(60, 'Books.Settings.Create', '', 'active'),
(61, 'Books.Settings.Edit', '', 'active'),
(62, 'Books.Settings.Delete', '', 'active'),
(63, 'Books.Developer.View', '', 'active'),
(64, 'Books.Developer.Create', '', 'active'),
(65, 'Books.Developer.Edit', '', 'active'),
(66, 'Books.Developer.Delete', '', 'active'),
(67, 'Test.Content.View', '', 'active'),
(68, 'Test.Content.Create', '', 'active'),
(69, 'Test.Content.Edit', '', 'active'),
(70, 'Test.Content.Delete', '', 'active'),
(71, 'Test.Reports.View', '', 'active'),
(72, 'Test.Reports.Create', '', 'active'),
(73, 'Test.Reports.Edit', '', 'active'),
(74, 'Test.Reports.Delete', '', 'active'),
(75, 'Test.Settings.View', '', 'active'),
(76, 'Test.Settings.Create', '', 'active'),
(77, 'Test.Settings.Edit', '', 'active'),
(78, 'Test.Settings.Delete', '', 'active'),
(79, 'Test.Developer.View', '', 'active'),
(80, 'Test.Developer.Create', '', 'active'),
(81, 'Test.Developer.Edit', '', 'active'),
(82, 'Test.Developer.Delete', '', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `bf_rack`
--

CREATE TABLE IF NOT EXISTS `bf_rack` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `description` varchar(100) DEFAULT NULL,
  `deleted` tinyint(4) NOT NULL DEFAULT '0',
  `created_on` datetime DEFAULT '0000-00-00 00:00:00',
  `modified_on` datetime DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `bf_rack`
--

INSERT INTO `bf_rack` (`id`, `name`, `description`, `deleted`, `created_on`, `modified_on`) VALUES
(4, '1', 'test xyz123', 0, '2014-03-15 03:39:25', '2014-03-22 03:49:49'),
(5, '5', 'qwerty', 0, '2014-03-19 01:34:55', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `bf_roles`
--

CREATE TABLE IF NOT EXISTS `bf_roles` (
  `role_id` int(11) NOT NULL AUTO_INCREMENT,
  `role_name` varchar(60) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `default` tinyint(1) NOT NULL DEFAULT '0',
  `can_delete` tinyint(1) NOT NULL DEFAULT '1',
  `login_destination` varchar(255) NOT NULL DEFAULT '/',
  `deleted` int(1) NOT NULL DEFAULT '0',
  `default_context` varchar(255) NOT NULL DEFAULT 'content',
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `bf_roles`
--

INSERT INTO `bf_roles` (`role_id`, `role_name`, `description`, `default`, `can_delete`, `login_destination`, `deleted`, `default_context`) VALUES
(1, 'Administrator', 'Has full control over every aspect of the site.', 0, 0, '', 0, 'content'),
(2, 'Editor', 'Can handle day-to-day management, but does not have full power.', 0, 1, '', 0, 'content'),
(4, 'User', 'This is the default user with access to login.', 1, 0, '', 0, 'content'),
(6, 'Developer', 'Developers typically are the only ones that can access the developer tools. Otherwise identical to Administrators, at least until the site is handed off.', 0, 1, '', 0, 'content');

-- --------------------------------------------------------

--
-- Table structure for table `bf_role_permissions`
--

CREATE TABLE IF NOT EXISTS `bf_role_permissions` (
  `role_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`role_id`,`permission_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `bf_role_permissions`
--

INSERT INTO `bf_role_permissions` (`role_id`, `permission_id`) VALUES
(1, 1),
(1, 2),
(1, 3),
(1, 4),
(1, 5),
(1, 6),
(1, 7),
(1, 8),
(1, 9),
(1, 10),
(1, 11),
(1, 12),
(1, 13),
(1, 14),
(1, 15),
(1, 16),
(1, 17),
(1, 18),
(1, 19),
(1, 20),
(1, 21),
(1, 22),
(1, 24),
(1, 25),
(1, 27),
(1, 28),
(1, 29),
(1, 30),
(1, 31),
(1, 32),
(1, 33),
(1, 34),
(1, 35),
(1, 36),
(1, 37),
(1, 38),
(1, 39),
(1, 40),
(1, 41),
(1, 42),
(1, 43),
(1, 44),
(1, 45),
(1, 46),
(1, 47),
(1, 48),
(1, 49),
(1, 50),
(1, 51),
(1, 52),
(1, 53),
(1, 54),
(1, 55),
(1, 56),
(1, 57),
(1, 58),
(1, 59),
(1, 60),
(1, 61),
(1, 62),
(1, 63),
(1, 64),
(1, 65),
(1, 66),
(1, 67),
(1, 68),
(1, 69),
(1, 70),
(1, 71),
(1, 72),
(1, 73),
(1, 74),
(1, 75),
(1, 76),
(1, 77),
(1, 78),
(1, 79),
(1, 80),
(1, 81),
(1, 82),
(2, 1),
(2, 2),
(2, 3),
(4, 1),
(6, 1),
(6, 2),
(6, 3),
(6, 4),
(6, 5),
(6, 6),
(6, 7),
(6, 8),
(6, 9),
(6, 10),
(6, 11),
(6, 12),
(6, 13),
(6, 49);

-- --------------------------------------------------------

--
-- Table structure for table `bf_schema_version`
--

CREATE TABLE IF NOT EXISTS `bf_schema_version` (
  `type` varchar(40) NOT NULL,
  `version` int(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `bf_schema_version`
--

INSERT INTO `bf_schema_version` (`type`, `version`) VALUES
('app_', 0),
('core', 34),
('test_', 2);

-- --------------------------------------------------------

--
-- Table structure for table `bf_sessions`
--

CREATE TABLE IF NOT EXISTS `bf_sessions` (
  `session_id` varchar(40) NOT NULL DEFAULT '0',
  `ip_address` varchar(45) NOT NULL DEFAULT '0',
  `user_agent` varchar(120) NOT NULL,
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `user_data` text,
  PRIMARY KEY (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `bf_sessions`
--


-- --------------------------------------------------------

--
-- Table structure for table `bf_settings`
--

CREATE TABLE IF NOT EXISTS `bf_settings` (
  `name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `module` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`name`),
  UNIQUE KEY `unique - name` (`name`),
  KEY `index - name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `bf_settings`
--

INSERT INTO `bf_settings` (`name`, `module`, `value`) VALUES
('auth.allow_name_change', 'core', '1'),
('auth.allow_register', 'core', '1'),
('auth.allow_remember', 'core', '1'),
('auth.do_login_redirect', 'core', '1'),
('auth.login_type', 'core', 'email'),
('auth.name_change_frequency', 'core', '1'),
('auth.name_change_limit', 'core', '1'),
('auth.password_force_mixed_case', 'core', '0'),
('auth.password_force_numbers', 'core', '0'),
('auth.password_force_symbols', 'core', '0'),
('auth.password_min_length', 'core', '8'),
('auth.password_show_labels', 'core', '0'),
('auth.remember_length', 'core', '1209600'),
('auth.use_extended_profile', 'core', '0'),
('auth.use_usernames', 'core', '1'),
('auth.user_activation_method', 'core', '0'),
('form_save', 'core.ui', 'ctrl+s/⌘+s'),
('goto_content', 'core.ui', 'alt+c'),
('mailpath', 'email', '/usr/sbin/sendmail'),
('mailtype', 'email', 'text'),
('protocol', 'email', 'mail'),
('sender_email', 'email', 'admin@info.com'),
('site.languages', 'core', 'a:3:{i:0;s:7:"english";i:1;s:10:"portuguese";i:2;s:7:"persian";}'),
('site.list_limit', 'core', '25'),
('site.show_front_profiler', 'core', '1'),
('site.show_profiler', 'core', '1'),
('site.status', 'core', '1'),
('site.system_email', 'core', 'admin@info.com'),
('site.title', 'core', 'Book keeper'),
('smtp_host', 'email', ''),
('smtp_pass', 'email', ''),
('smtp_port', 'email', ''),
('smtp_timeout', 'email', ''),
('smtp_user', 'email', ''),
('updates.bleeding_edge', 'core', '1'),
('updates.do_check', 'core', '1');

-- --------------------------------------------------------

--
-- Table structure for table `bf_shelf`
--

CREATE TABLE IF NOT EXISTS `bf_shelf` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `rack_id` int(10) NOT NULL DEFAULT '0',
  `shelf_number` int(10) NOT NULL DEFAULT '0',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_on` datetime DEFAULT '0000-00-00 00:00:00',
  `modified_on` datetime DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `bf_shelf`
--

INSERT INTO `bf_shelf` (`id`, `rack_id`, `shelf_number`, `deleted`, `created_on`, `modified_on`) VALUES
(4, 4, 4, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(6, 4, 6, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(7, 5, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(8, 5, 2, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(9, 5, 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `bf_shelf_detail`
--

CREATE TABLE IF NOT EXISTS `bf_shelf_detail` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `shelf_id` int(10) NOT NULL DEFAULT '0',
  `book_copy_id` int(10) NOT NULL DEFAULT '0',
  `created_on` datetime DEFAULT '0000-00-00 00:00:00',
  `modified_on` datetime DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `bf_shelf_detail`
--

INSERT INTO `bf_shelf_detail` (`id`, `shelf_id`, `book_copy_id`, `created_on`, `modified_on`) VALUES
(1, 6, 16, '2014-03-22 02:58:06', '2014-03-22 03:01:01'),
(3, 4, 15, '2014-03-30 11:16:17', '0000-00-00 00:00:00'),
(11, 8, 11, '2014-04-05 12:09:57', '0000-00-00 00:00:00'),
(12, 4, 30, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(13, 9, 31, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(15, 8, 33, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(16, 8, 37, '2014-08-06 02:35:48', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `bf_student`
--

CREATE TABLE IF NOT EXISTS `bf_student` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `address` varchar(500) NOT NULL,
  `course` varchar(50) NOT NULL,
  `batch` varchar(50) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `phone` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `bf_student`
--

INSERT INTO `bf_student` (`id`, `name`, `address`, `course`, `batch`, `deleted`, `created_on`, `modified_on`, `phone`) VALUES
(1, 'Omar Gallagher', '8827 Odio. St.', 'Vel Pede LLP', 'F', 1, '2014-01-28 19:44:38', '2013-06-03 05:02:26', NULL),
(2, 'Griffith Chapman', 'P.O. Box 782, 2994 Dis Rd.', 'Libero Associates', 'G', 1, '2013-03-29 01:20:20', '2013-06-14 02:32:04', NULL),
(3, 'Brendan Miranda', '150-5598 Lacinia Rd.', 'Sapien Consulting', 'P', 1, '2013-11-08 16:04:15', '2013-07-19 19:32:32', NULL),
(4, 'Andrew Sawyer', 'Ap #981-2995 Cras Street', 'Libero Nec Institute', 'W', 1, '2013-11-04 23:58:46', '2013-03-25 10:19:27', NULL),
(5, 'Driscoll Bright', 'Ap #738-3325 Magna Rd.', 'Turpis In Condimentum Institute', 'K', 1, '2013-11-06 22:09:49', '2013-09-21 19:16:09', NULL),
(6, 'Fulton Kidd', '6031 Placerat. Road', 'Gravida Institute', 'G', 1, '2014-01-07 03:37:42', '2013-07-13 18:45:26', NULL),
(7, 'Malachi Mcdaniel', 'P.O. Box 203, 5138 Quisque St.', 'Fringilla Mi Lacinia Foundation', 'Y', 1, '2013-06-11 00:54:38', '2013-11-11 13:41:24', NULL),
(8, 'Magee Woods', '338-9414 Pede, Ave', 'Quisque Tincidunt LLP', 'K', 1, '2013-09-01 23:38:57', '2013-03-29 21:56:20', NULL),
(9, 'Mufutau Whitley', 'P.O. Box 801, 6135 Odio St.', 'Pede Industries', 'Y', 1, '2013-07-22 10:03:50', '2013-06-29 14:44:02', NULL),
(10, 'Scott Adams', '2416 At, Ave', 'Hendrerit Consectetuer Industries', 'U', 1, '2013-06-22 08:50:43', '2013-05-24 16:05:17', NULL),
(11, 'Zuhair', 'abc,abc', 'a1', 'a2', 1, '2014-02-14 19:43:23', '0000-00-00 00:00:00', NULL),
(12, 'test_student', 'test address', 'abc', 'abc', 1, '2014-04-02 03:18:48', '0000-00-00 00:00:00', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `bf_users`
--

CREATE TABLE IF NOT EXISTS `bf_users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL DEFAULT '4',
  `email` varchar(120) NOT NULL,
  `username` varchar(30) NOT NULL DEFAULT '',
  `password_hash` varchar(40) NOT NULL,
  `reset_hash` varchar(40) DEFAULT NULL,
  `salt` varchar(7) NOT NULL,
  `last_login` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_ip` varchar(40) NOT NULL DEFAULT '',
  `created_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `banned` tinyint(1) NOT NULL DEFAULT '0',
  `ban_message` varchar(255) DEFAULT NULL,
  `reset_by` int(10) DEFAULT NULL,
  `display_name` varchar(255) DEFAULT '',
  `display_name_changed` date DEFAULT NULL,
  `timezone` char(4) NOT NULL DEFAULT 'UM6',
  `language` varchar(20) NOT NULL DEFAULT 'english',
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `activate_hash` varchar(40) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `email` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `bf_users`
--

INSERT INTO `bf_users` (`id`, `role_id`, `email`, `username`, `password_hash`, `reset_hash`, `salt`, `last_login`, `last_ip`, `created_on`, `deleted`, `banned`, `ban_message`, `reset_by`, `display_name`, `display_name_changed`, `timezone`, `language`, `active`, `activate_hash`) VALUES
(1, 1, 'admin@info.com', 'admin', '72a15595642d1d6b9469413bb9d4a950e21df9fa', NULL, 'WzCQQPB', '2015-01-19 06:33:26', '127.0.0.1', '0000-00-00 00:00:00', 0, 0, NULL, NULL, '', NULL, 'UM6', 'english', 1, '');

-- --------------------------------------------------------

--
-- Table structure for table `bf_user_cookies`
--

CREATE TABLE IF NOT EXISTS `bf_user_cookies` (
  `user_id` bigint(20) NOT NULL,
  `token` varchar(128) NOT NULL,
  `created_on` datetime NOT NULL,
  KEY `token` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `bf_user_cookies`
--

INSERT INTO `bf_user_cookies` (`user_id`, `token`, `created_on`) VALUES
(1, 'e8FAooNj7pJcxBDbYhsYpFe9YJZl34UeZjciIl18aGbojShbG8LgKVRfIBH6I7sXCp1SydCFQq1COL8s3e20Od5kNPNIditvIgppG9A7ZcxkonAugVpfKrxUOQu0r1FD', '2014-01-14 05:20:32'),
(1, 's3q5pGKn1U4LxKWI1dXSFlY6CAcspNvWaLnDc3Sh4fmm049PvyN8tlWYnhyPmOILBDGkWHghyv2QPwZeT37l0rqXFRL7dfow4eP2wCIRydh2UQbgeRjbhQdU82F0RRJn', '2006-12-31 18:56:21'),
(1, 'bGpWK442KShgGy12XZToayDqqbHv77MBmtJt0ZtjKy8HEdWpAxME5btIGtlGupBntOEVStUwzUHEsvuoZyNby8umQ757few1qOjtW4GlDWn4zBsJn2LQv4EmKCZpjZ5U', '2014-03-29 12:16:43');

-- --------------------------------------------------------

--
-- Table structure for table `bf_user_meta`
--

CREATE TABLE IF NOT EXISTS `bf_user_meta` (
  `meta_id` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) NOT NULL DEFAULT '',
  `meta_value` text,
  PRIMARY KEY (`meta_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `bf_user_meta`
--

